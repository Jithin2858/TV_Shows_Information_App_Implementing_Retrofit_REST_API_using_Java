package com.example.machinetest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.SerializedName;

import java.io.File;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public class MainActivity extends AppCompatActivity {
    public static String baseUrl = "https://api.tvmaze.com/"; //for testing  shows
    RecyclerView mRecyclerView;
    ShowsAdapter mAdapter;
    List<ShowsModel> mList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAdapter = new ShowsAdapter(getApplicationContext(), mList);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        mRecyclerView.setAdapter(mAdapter);
        getClient(getApplicationContext())
                .create(ShowsInterface.class)
                .getShows()
                .enqueue(new Callback<List<ShowsModel>>() {
                    @Override
                    public void onResponse(@NonNull Call<List<ShowsModel>> call, @NonNull Response<List<ShowsModel>> response) {
                        mList = response.body();
                        mAdapter = new ShowsAdapter(getApplicationContext(), mList);
                        mRecyclerView.setAdapter(mAdapter);
                    }

                    @Override
                    public void onFailure(@NonNull Call<List<ShowsModel>> call, @NonNull Throwable t) {

                    }
                });


    }

    static public Retrofit getClient(Context ctx) {
        Gson gson = new GsonBuilder()
                .enableComplexMapKeySerialization()
                .serializeNulls()
                .setDateFormat(DateFormat.LONG)
                .setVersion(1.0)
                .setLenient()
                .create();
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        return new Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(httpClient.build())
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

    }

    public interface ShowsInterface {

        @GET("shows/")
        Call<List<ShowsModel>> getShows();
    }

    public static class ShowsModel {

        public static class ShowsImageModel {

            private String medium;

            private String original;

            public String getMedium() {
                return medium;
            }

            public void setMedium(String medium) {
                this.medium = medium;
            }

            public String getOriginal() {
                return original;
            }

            public void setOriginal(String original) {
                this.original = original;
            }
        }

        public static class ShowRatingModel {

            private float average;

            public float getAverage() {
                return average;
            }

            public void setAverage(float average) {
                this.average = average;
            }
        }


        private String id;

        private String name;

        private String summary;

        private ShowsImageModel image;

        private ShowRatingModel rating;

        private List<String> genres;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getSummary() {
            return summary;
        }

        public void setSummary(String summary) {
            this.summary = summary;
        }

        public ShowsImageModel getImage() {
            return image;
        }

        public void setImage(ShowsImageModel image) {
            this.image = image;
        }

        public ShowRatingModel getRating() {
            return rating;
        }

        public void setRating(ShowRatingModel rating) {
            this.rating = rating;
        }

        public List<String> getGenres() {
            return genres;
        }

        public void setGenres(List<String> genres) {
            this.genres = genres;
        }
    }
    
    static class ShowsAdapter extends RecyclerView.Adapter<ShowsViewHolder> {
        List<ShowsModel> dispatchList;
        Context context;

        ShowsAdapter(Context mContext, List<ShowsModel> mDeliveredList) {
            this.dispatchList = mDeliveredList;
            this.context = mContext;
        }

        @NonNull
        @Override
        public ShowsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.show, parent, false);
            return new ShowsViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ShowsViewHolder holder, int position) {

        }

        @Override
        public int getItemCount() {
            return dispatchList.size();
        }
    }

    static class ShowsViewHolder extends RecyclerView.ViewHolder {
        public ShowsViewHolder(@NonNull View itemView) {
            super(itemView);
            //itemView.setOnClickListener();
        }
    }

    static class GenreAdapter extends RecyclerView.Adapter<GenreViewHolder> {
        List<ShowsModel> dispatchList;
        Context context;

        GenreAdapter(Context mContext, List<ShowsModel> mDeliveredList) {
            this.dispatchList = mDeliveredList;
            this.context = mContext;
        }

        @NonNull
        @Override
        public GenreViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.genre, parent, false);
            return new GenreViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull GenreViewHolder holder, int position) {

        }

        @Override
        public int getItemCount() {
            return dispatchList.size();
        }
    }

    static class GenreViewHolder extends RecyclerView.ViewHolder {
        public GenreViewHolder(@NonNull View itemView) {
            super(itemView);
            //itemView.setOnClickListener();
        }
    }

}